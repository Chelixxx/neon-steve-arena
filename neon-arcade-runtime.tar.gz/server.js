'use strict';
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const {WebSocketServer}=require('ws');
const PORT=Number(process.env.PORT||8000),ROOT=path.join(__dirname,'public');
const WORLD={agar:{w:5000,h:3500},snake:{w:5000,h:3500},shooter:{w:1800,h:1200},blocks:{w:1800,h:1200}};
const rooms={agar:new Map(),snake:new Map(),shooter:new Map(),blocks:new Map()};
const pellets=new Map(),bullets=new Map(),blockTiles=new Set();
const rand=(a,b)=>a+Math.random()*(b-a),clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const cleanName=s=>String(s||'Player').replace(/[^\p{L}\p{N} _-]/gu,'').trim().slice(0,16)||'Player';
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.webp':'image/webp','.json':'application/json'};
function spawnPellet(){const id=crypto.randomUUID();pellets.set(id,{id,x:rand(25,4975),y:rand(25,3475),r:rand(4,8),color:Math.floor(rand(0,360))});}
for(let i=0;i<650;i++)spawnPellet();
// Lightweight block-world obstacles. Shared across sessions.
for(let i=0;i<95;i++){const x=Math.floor(rand(4,44)),y=Math.floor(rand(3,27));blockTiles.add(`${x},${y}`)}
const server=http.createServer((req,res)=>{
 let pathname;try{pathname=decodeURIComponent(new URL(req.url,'http://localhost').pathname)}catch{res.writeHead(400);return res.end('Bad request')}
 if(pathname==='/health'){res.writeHead(200,{'Content-Type':'application/json'});return res.end(JSON.stringify({ok:true,players:Object.values(rooms).reduce((n,r)=>n+r.size,0),games:Object.fromEntries(Object.entries(rooms).map(([k,v])=>[k,v.size]))}))}
 if(pathname==='/')pathname='/index.html';
 const file=path.resolve(ROOT,'.'+pathname);if(!(file===ROOT||file.startsWith(ROOT+path.sep))){res.writeHead(403);return res.end('Forbidden')}
 fs.stat(file,(err,st)=>{if(err||!st.isFile()){res.writeHead(404,{'Content-Type':'text/plain; charset=utf-8'});return res.end('Not found')};res.writeHead(200,{'Content-Type':types[path.extname(file)]||'application/octet-stream','Cache-Control':'no-cache'});fs.createReadStream(file).pipe(res)});
});
const wss=new WebSocketServer({server,path:'/ws',maxPayload:4096});
function send(ws,obj){if(ws.readyState===1)ws.send(JSON.stringify(obj))}
function playerPublic(p){if(p.game==='snake')return {id:p.id,name:p.name,x:p.x,y:p.y,body:p.body,color:p.color,score:p.score,alive:p.alive};if(p.game==='agar')return {id:p.id,name:p.name,x:p.x,y:p.y,mass:p.mass,color:p.color,score:p.score};if(p.game==='shooter')return {id:p.id,name:p.name,x:p.x,y:p.y,hp:p.hp,color:p.color,score:p.score,angle:p.angle};return {id:p.id,name:p.name,x:p.x,y:p.y,hp:p.hp,color:p.color,score:p.score,dir:p.dir};}
function sendState(game){const r=rooms[game],players=[...r.values()].map(playerPublic);let extras={};if(game==='agar')extras.pellets=[...pellets.values()];if(game==='shooter')extras.bullets=[...bullets.values()].filter(b=>b.game===game).map(({game,...b})=>b);if(game==='blocks')extras.tiles=[...blockTiles];const data=JSON.stringify({t:'state',game,w:WORLD[game].w,h:WORLD[game].h,players,...extras});for(const p of r.values())if(p.ws.readyState===1&&p.ws.bufferedAmount<180000)p.ws.send(data)}
function spawnPlayer(game,id,name,ws){const w=WORLD[game],p={id,game,name,ws,x:rand(100,w.w-100),y:rand(100,w.h-100),dx:0,dy:0,color:Math.floor(rand(0,360)),score:0,angle:0,hp:100,fireCd:0,attackCd:0};if(game==='agar')p.mass=18;if(game==='snake'){p.body=[];p.dir=0;p.nextDir=0;p.step=0;p.alive=true;for(let i=0;i<5;i++)p.body.push({x:p.x-i*18,y:p.y});}if(game==='blocks')p.dir=0;return p}
function respawn(p){const w=WORLD[p.game];p.x=rand(100,w.w-100);p.y=rand(100,w.h-100);p.dx=p.dy=0;p.hp=100;if(p.game==='agar')p.mass=18;if(p.game==='snake'){p.alive=true;p.body=[];p.dir=p.nextDir=0;for(let i=0;i<5;i++)p.body.push({x:p.x-i*18,y:p.y})}}
wss.on('connection',ws=>{let p=null;ws.on('message',raw=>{let m;try{m=JSON.parse(raw)}catch{return}if(!m||typeof m!=='object')return;
 if(m.t==='join'&&!p){const game=['agar','snake','shooter','blocks'].includes(m.game)?m.game:'agar';const id=crypto.randomUUID();p=spawnPlayer(game,id,cleanName(m.name),ws);rooms[game].set(id,p);send(ws,{t:'hello',id,game,w:WORLD[game].w,h:WORLD[game].h,blockSize:40});return}
 if(!p)return;
 if(m.t==='input'){if(p.game==='snake'){const d=Number(m.dir);if(Number.isFinite(d)&&d>=0&&d<=3){const opposite=(p.dir+2)%4;if(d!==opposite)p.nextDir=d;}return}
 let x=Number(m.x),y=Number(m.y);if(!Number.isFinite(x)||!Number.isFinite(y))return;const l=Math.hypot(x,y);p.dx=l?clamp(x/l,-1,1):0;p.dy=l?clamp(y/l,-1,1):0;if(p.game==='shooter'||p.game==='blocks'){const a=Number(m.angle);if(Number.isFinite(a))p.angle=a}if(p.game==='shooter'&&m.fire&&Date.now()>=p.fireCd){p.fireCd=Date.now()+240;const id=crypto.randomUUID();bullets.set(id,{id,game:'shooter',owner:p.id,x:p.x+Math.cos(p.angle)*24,y:p.y+Math.sin(p.angle)*24,dx:Math.cos(p.angle)*600,dy:Math.sin(p.angle)*600,life:1.4,color:p.color})}if(p.game==='blocks'&&m.attack&&Date.now()>=p.attackCd){p.attackCd=Date.now()+450;for(const other of rooms.blocks.values()){if(other.id===p.id)continue;const dist=Math.hypot(other.x-p.x,other.y-p.y);if(dist<62){other.hp-=25;if(other.hp<=0){p.score+=1;respawn(other)}}}}
 }
 if(p.game==='blocks'&&m.t==='tile'){const tx=Math.floor(Number(m.x)/40),ty=Math.floor(Number(m.y)/40);if(!Number.isFinite(tx)||!Number.isFinite(ty)||tx<0||tx>=45||ty<0||ty>=30)return;const key=`${tx},${ty}`;if(blockTiles.has(key))blockTiles.delete(key);else if(blockTiles.size<700)blockTiles.add(key)}
 if(m.t==='rename')p.name=cleanName(m.name);
 });ws.on('close',()=>{if(p)rooms[p.game].delete(p.id)});ws.on('error',()=>{});
});
let last=Date.now(),snakeTick=0;setInterval(()=>{const now=Date.now(),dt=Math.min((now-last)/1000,.05);last=now;
 // Agar-like arena: server authoritative movement, pellet eating and player-versus-player.
 for(const p of rooms.agar.values()){const speed=Math.max(90,260/Math.pow(p.mass/18,.24));p.x=clamp(p.x+p.dx*speed*dt,15,4985);p.y=clamp(p.y+p.dy*speed*dt,15,3485);for(const [id,g] of pellets){if(Math.hypot(p.x-g.x,p.y-g.y)<Math.sqrt(p.mass)+g.r){p.mass+=.7;p.score+=1;pellets.delete(id);spawnPellet()}}}
 const agar=[...rooms.agar.values()];for(const a of agar)for(const b of agar){if(a.id===b.id||a.mass<=b.mass*1.12)continue;if(Math.hypot(a.x-b.x,a.y-b.y)<Math.sqrt(a.mass)*1.2+Math.sqrt(b.mass)*.65){a.mass+=b.mass*.72;a.score+=Math.max(5,Math.round(b.mass));respawn(b);b.mass=18;b.score=0}}
 // Classic pixel snake. Grid movement on a 5x larger map; head/body collision kills and respawns.
 snakeTick+=dt;if(snakeTick>=.115){snakeTick=0;for(const p of rooms.snake.values()){if(!p.alive)continue;p.dir=p.nextDir;const dirs=[[18,0],[0,18],[-18,0],[0,-18]],v=dirs[p.dir];p.x=clamp(p.x+v[0],18,4982);p.y=clamp(p.y+v[1],18,3482);p.body.unshift({x:p.x,y:p.y});let ate=false;for(const [id,g] of pellets){if(Math.hypot(p.x-g.x,p.y-g.y)<20){pellets.delete(id);spawnPellet();p.score++;ate=true;break}}if(!ate)p.body.pop();if(p.body.length>150)p.body.length=150}}
 const snakes=[...rooms.snake.values()].filter(p=>p.alive);for(const p of snakes){let dead=false;for(let i=5;i<p.body.length;i++)if(Math.hypot(p.x-p.body[i].x,p.y-p.body[i].y)<12){dead=true;break}for(const other of snakes){if(other.id===p.id)continue;for(let i=0;i<other.body.length;i++){if(Math.hypot(p.x-other.body[i].x,p.y-other.body[i].y)<12){dead=true;break}}if(dead)break}if(dead){p.score=0;respawn(p)}}
 // Top-down online shooter: movement, server-side bullets and damage.
 for(const p of rooms.shooter.values()){p.x=clamp(p.x+p.dx*230*dt,18,1782);p.y=clamp(p.y+p.dy*230*dt,18,1182)}for(const [id,b] of bullets){b.x+=b.dx*dt;b.y+=b.dy*dt;b.life-=dt;let hit=false;for(const p of rooms.shooter.values()){if(p.id===b.owner)continue;if(Math.hypot(p.x-b.x,p.y-b.y)<22){p.hp-=34;hit=true;if(p.hp<=0){const owner=rooms.shooter.get(b.owner);if(owner)owner.score++;respawn(p)}break}}if(hit||b.life<=0||b.x<0||b.x>1800||b.y<0||b.y>1200)bullets.delete(id)}
 // Block-world PvP movement, with collision against placed blocks.
 for(const p of rooms.blocks.values()){const nx=clamp(p.x+p.dx*180*dt,15,1785),ny=clamp(p.y+p.dy*180*dt,15,1185);const key=`${Math.floor(nx/40)},${Math.floor(ny/40)}`;if(!blockTiles.has(key)){p.x=nx;p.y=ny}}
},1000/30);
setInterval(()=>{for(const game of Object.keys(rooms))sendState(game)},100);
server.listen(PORT,'0.0.0.0',()=>console.log(`NEON ARCADE listening on ${PORT}`));
